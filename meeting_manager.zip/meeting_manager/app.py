from flask import Flask, render_template, request, redirect, url_for, flash, session
import sqlite3
import re

app = Flask(__name__)
app.secret_key = 'meeting_manager_secret_key'
app.config['SESSION_PERMANENT'] = False
app.config['SESSION_TYPE'] = 'filesystem'
DB_PATH = 'meeting.db'

# 注册模板全局函数
@app.template_global()
def format_time_24h(time_str):
    """将时间字符串统一格式化为24小时制 HH:MM 格式"""
    if not time_str:
        return "19:30"
    
    total_minutes = parse_meeting_start_time(time_str)
    hours = total_minutes // 60
    minutes = total_minutes % 60
    return f"{hours:02d}:{minutes:02d}"

# 全局语言设置路由
@app.route('/set_lang/<lang>')
def set_language(lang):
    """设置全局语言"""
    session['lang'] = lang
    # 返回上一页
    return redirect(request.referrer or url_for('index'))

@app.before_request
def before_request():
    """每个请求默认语言为中文"""
    if 'lang' not in session:
        session['lang'] = 'zh'

def parse_meeting_start_time(time_str):
    """从会议时间字符串中提取开始时间（分钟）
    
    优先使用会议正式时间（如19:30-），而不是签到时间（如19:00 Sign-in）
    支持中英文格式，包括：19:30, 7:30pm, 7:30 PM, 晚上7点半等
    最终统一转换为24小时制
    """
    if not time_str:
        return 19 * 60 + 30  # 默认19:30
    
    # 尝试匹配带 AM/PM 的时间格式 (如 7:30pm, 7:30 PM, 7:30am)
    match = re.search(r'(\d{1,2}):(\d{2})\s*(am|pm|AM|PM|a\.m\.|p\.m\.)', time_str, re.IGNORECASE)
    if match:
        hour = int(match.group(1))
        minute = int(match.group(2))
        period = match.group(3).lower()
        
        # 转换为24小时制
        if 'pm' in period or 'p.m.' in period:
            if hour != 12:  # 12pm 是中午12点，不需要加12
                hour += 12
        elif 'am' in period or 'a.m.' in period:
            if hour == 12:  # 12am 是午夜0点
                hour = 0
        
        return hour * 60 + minute
    
    # 匹配中文时间描述 (如 晚上7点半, 下午7点30分)
    match = re.search(r'(?:晚上|下午|傍晚|晚间)(\d{1,2})[:点时](\d{0,2})', time_str)
    if match:
        hour = int(match.group(1))
        minute_str = match.group(2)
        minute = int(minute_str) if minute_str else 0
        
        # 晚上/下午通常是PM，转换为24小时制
        if hour < 12:
            hour += 12
        
        return hour * 60 + minute
    
    # 匹配上午时间 (如 上午9点, 早上10点)
    match = re.search(r'(?:上午|早上|早晨)(\d{1,2})[:点时](\d{0,2})', time_str)
    if match:
        hour = int(match.group(1))
        minute_str = match.group(2)
        minute = int(minute_str) if minute_str else 0
        
        # 处理12am的情况
        if hour == 12:
            hour = 0
        
        return hour * 60 + minute
    
    # 优先匹配会议正式时间（19:30- 这种格式，在括号内 - 中文格式）
    match = re.search(r'[（(](\d{1,2}):(\d{2})', time_str)
    if match:
        hour = int(match.group(1))
        minute = int(match.group(2))
        return hour * 60 + minute
    
    # 备选：匹配 19:30- 这种格式（连字符后）
    match = re.search(r'(\d{1,2}):(\d{2})\s*[-–—]', time_str)
    if match:
        hour = int(match.group(1))
        minute = int(match.group(2))
        return hour * 60 + minute
    
    # 再次备选：匹配括号外的时间 19:30
    match = re.search(r'(\d{1,2}):(\d{2})', time_str)
    if match:
        hour = int(match.group(1))
        minute = int(match.group(2))
        # 只接受合理的小时范围 (7-23点)
        if 7 <= hour <= 23:
            return hour * 60 + minute
    
    return 19 * 60 + 30  # 默认19:30

def format_time_24h(time_str):
    """将时间字符串统一格式化为24小时制 HH:MM 格式
    
    支持多种输入格式：
    - "19:30" -> "19:30"
    - "7:30pm" -> "19:30"
    - "7:30 PM" -> "19:30"
    - "晚上7点半" -> "19:30"
    - "2026/5/1 周五晚（19:30-21:30，19:00 签到）" -> "19:30"
    """
    if not time_str:
        return "19:30"
    
    total_minutes = parse_meeting_start_time(time_str)
    hours = total_minutes // 60
    minutes = total_minutes % 60
    return f"{hours:02d}:{minutes:02d}"

DEFAULT_ROLES = [
    {'name_zh': '会议经理', 'name_en': 'Meeting Manager', 'abbrev': 'MM', 'member_only': True, 'desc_zh': '负责会议整体统筹和角色预订，确保会议顺利进行', 'desc_en': 'Responsible for overall meeting coordination and role booking'},
    {'name_zh': '接待官', 'name_en': 'Sargeant-at-Arms', 'abbrev': 'SAA', 'member_only': False, 'desc_zh': '负责签到、开场致辞和嘉宾介绍', 'desc_en': 'Responsible for sign-in, opening remarks and guest introduction'},
    {'name_zh': '总主持', 'name_en': 'Toastmaster', 'abbrev': 'TOM', 'member_only': True, 'desc_zh': '控制会议流程，引导各环节顺利衔接', 'desc_en': 'Controls meeting flow and guides transitions between segments'},
    {'name_zh': '时间官', 'name_en': 'Timer', 'abbrev': 'Timer', 'member_only': False, 'desc_zh': '记录每位演讲者时间并做报告', 'desc_en': 'Tracks time for each speaker and reports'},
    {'name_zh': '游戏官', 'name_en': 'Game Master', 'abbrev': 'GM', 'member_only': False, 'desc_zh': '设计互动游戏增加会议趣味性', 'desc_en': 'Designs interactive games for meeting fun'},
    {'name_zh': '摄影师', 'name_en': 'Photographer', 'abbrev': 'Photo', 'member_only': False, 'desc_zh': '捕捉会议精彩瞬间留念', 'desc_en': 'Captures memorable meeting moments'},
    {'name_zh': '总点评', 'name_en': 'General Evaluator', 'abbrev': 'GE', 'member_only': True, 'desc_zh': '整体点评所有演讲者和角色表现', 'desc_en': 'Evaluates all speakers and role holders overall'},
    {'name_zh': '备稿演讲1', 'name_en': 'Prepared Speech 1', 'abbrev': 'PS1', 'member_only': True, 'desc_zh': '准备好的演讲（5-7分钟）', 'desc_en': 'Prepared speech (5-7 minutes)'},
    {'name_zh': '备稿演讲2', 'name_en': 'Prepared Speech 2', 'abbrev': 'PS2', 'member_only': True, 'desc_zh': '准备好的演讲（5-7分钟）', 'desc_en': 'Prepared speech (5-7 minutes)'},
    {'name_zh': '备稿演讲3', 'name_en': 'Prepared Speech 3', 'abbrev': 'PS3', 'member_only': True, 'desc_zh': '准备好的演讲（5-7分钟）', 'desc_en': 'Prepared speech (5-7 minutes)'},
    {'name_zh': '备稿演讲4', 'name_en': 'Prepared Speech 4', 'abbrev': 'PS4', 'member_only': True, 'desc_zh': '准备好的演讲（5-7分钟）', 'desc_en': 'Prepared speech (5-7 minutes)'},
    {'name_zh': '个评1', 'name_en': 'Individual Evaluator 1', 'abbrev': 'IE1', 'member_only': True, 'desc_zh': '点评备稿演讲1', 'desc_en': 'Evaluates Prepared Speech 1'},
    {'name_zh': '个评2', 'name_en': 'Individual Evaluator 2', 'abbrev': 'IE2', 'member_only': True, 'desc_zh': '点评备稿演讲2', 'desc_en': 'Evaluates Prepared Speech 2'},
    {'name_zh': '个评3', 'name_en': 'Individual Evaluator 3', 'abbrev': 'IE3', 'member_only': True, 'desc_zh': '点评备稿演讲3', 'desc_en': 'Evaluates Prepared Speech 3'},
    {'name_zh': '个评4', 'name_en': 'Individual Evaluator 4', 'abbrev': 'IE4', 'member_only': True, 'desc_zh': '点评备稿演讲4', 'desc_en': 'Evaluates Prepared Speech 4'},
    {'name_zh': '哼哈官', 'name_en': 'Ah-Counter', 'abbrev': 'Ah', 'member_only': False, 'desc_zh': '记录选手嗯哈次数帮助改进', 'desc_en': 'Counts fillers to help speakers improve'},
    {'name_zh': '语法官', 'name_en': 'Grammarian', 'abbrev': 'Gram', 'member_only': False, 'desc_zh': '记录好词好句及语言错误', 'desc_en': 'Notes good words and language errors'},
    {'name_zh': '即兴主持', 'name_en': 'Table Topics Master', 'abbrev': 'TTM', 'member_only': True, 'desc_zh': '邀请观众即兴演讲并抽取主题', 'desc_en': 'Invites table topics and selects themes'},
    {'name_zh': '即兴点评', 'name_en': 'Table Topics Evaluator', 'abbrev': 'TTE', 'member_only': True, 'desc_zh': '点评即兴演讲者表现', 'desc_en': 'Evaluates table topics speakers'},
    {'name_zh': '自由分享', 'name_en': 'Free Sharing', 'abbrev': 'Free', 'member_only': False, 'desc_zh': '开场自由分享环节', 'desc_en': 'Free sharing segment at opening'},
    {'name_zh': '嘉宾分享', 'name_en': 'Guest Sharing', 'abbrev': 'Guest', 'member_only': False, 'desc_zh': '会议结尾邀请嘉宾分享', 'desc_en': 'Invites guests to share at closing'},
    {'name_zh': '会长', 'name_en': 'President', 'abbrev': 'President', 'member_only': True, 'desc_zh': '俱乐部最高领导，负责闭幕和颁奖', 'desc_en': 'Club leader, closing and awards'},
]

def get_role_display_name(role, lang='zh'):
    """返回格式化的角色名: 中文名 (缩写) 或 Meeting Manager (MM)"""
    for r in DEFAULT_ROLES:
        if r['name_zh'] == role or r['abbrev'] == role:
            return f"{r['name_zh']} ({r['abbrev']})"
        if r['abbrev'] in role or r['name_zh'] in role:
            return f"{r['name_zh']} ({r['abbrev']})"
    
    # 未找到匹配，返回原样
    return role

def get_role_display_name_lang(role, lang='zh'):
    """根据语言返回格式化的角色名"""
    for r in DEFAULT_ROLES:
        if r['name_zh'] == role or r['abbrev'] == role:
            if lang == 'en':
                return f"{r['name_en']} ({r['abbrev']})"
            return f"{r['name_zh']} ({r['abbrev']})"
        if r['abbrev'] in role or r['name_zh'].replace('演讲','Speech').replace('个评','IE').replace('备稿','PS') in role or r['name_zh'] in role:
            if lang == 'en':
                return f"{r['name_en']} ({r['abbrev']})"
            return f"{r['name_zh']} ({r['abbrev']})"
    return role

def get_role_description(role, lang='zh'):
    """获取角色描述"""
    for r in DEFAULT_ROLES:
        if r['name_zh'] == role or r['abbrev'] == role:
            if lang == 'en':
                return r.get('desc_en', '')
            return r.get('desc_zh', '')
        if r['abbrev'] in role or r['name_zh'] in role:
            if lang == 'en':
                return r.get('desc_en', '')
            return r.get('desc_zh', '')
    return ''

def is_member_only_role(role_name):
    """检查角色是否仅限会员"""
    for r in DEFAULT_ROLES:
        if r['name_zh'] == role_name or r['abbrev'] == role_name:
            return r.get('member_only', False)
        if r['abbrev'] in role_name or r['name_zh'] in role_name:
            return r.get('member_only', False)
    return False

PHASE_CONFIG = [
    {"key": "init", "name_zh": "签到与开场", "name_en": "Init", "color": "bg-info text-white"},
    {"key": "table_topics", "name_zh": "即兴演讲", "name_en": "Table Topics", "color": "bg-warning"},
    {"key": "speech", "name_zh": "备稿演讲", "name_en": "Prepared Speech", "color": "bg-success text-white"},
    {"key": "break", "name_zh": "中场休息", "name_en": "Break", "color": "bg-secondary text-white"},
    {"key": "evaluation", "name_zh": "点评环节", "name_en": "Evaluation", "color": "bg-primary text-white"},
    {"key": "closing", "name_zh": "闭幕总结", "name_en": "Closing", "color": "bg-dark text-white"},
]

PHASE_TEMPLATES = {
    "init": [
        {"activity_zh": "会员嘉宾签到", "activity_en": "Guest & Members Sign In", "duration": 15, "role": "接待官(SAA)"},
        {"activity_zh": "宣布开会及规则介绍", "activity_en": "Calling for the meeting & rules intro", "duration": 4, "role": "接待官(SAA)"},
        {"activity_zh": "开场致辞及嘉宾介绍", "activity_en": "Opening remarks & Guests Introduction", "duration": 5, "role": "总主持(TOM)"},
        {"activity_zh": "TOM介绍会议角色", "activity_en": "TOM's Introduction of facilitators", "duration": 2, "role": "总主持(TOM)"},
        {"activity_zh": "摄影师介绍", "activity_en": "Introduction of Photographer", "duration": 1, "role": "摄影师(Photographer)"},
        {"activity_zh": "时间官介绍", "activity_en": "Introduction of Timer", "duration": 2, "role": "时间官(Timer)"},
        {"activity_zh": "哼哈官介绍", "activity_en": "Introduction of Ah Counter", "duration": 2, "role": "哼哈官(Ah-Counter)"},
        {"activity_zh": "语法官介绍", "activity_en": "Introduction of Grammarian", "duration": 2, "role": "语法官(Grammarian)"},
        {"activity_zh": "总点评介绍", "activity_en": "Introduction of General Evaluator", "duration": 2, "role": "总点评(GE)"},
        {"activity_zh": "自由分享", "activity_en": "Free Sharing", "duration": 2, "role": "自由分享(Free Sharing)"},
    ],
    "table_topics": [
        {"activity_zh": "TOM过渡到即兴环节", "activity_en": "TOM's Transition for Table Topics", "duration": 1, "role": "总主持(TOM)"},
        {"activity_zh": "即兴演讲", "activity_en": "Table topics speeches", "duration": 16, "role": "即兴主持(TTM)"},
        {"activity_zh": "即兴点评", "activity_en": "Table topics evaluation", "duration": 6, "role": "即兴点评(TTE)"},
    ],
    "speech": [
        {"activity_zh": "TOM过渡到备稿演讲", "activity_en": "TOM's Transition for Prepared Speeches", "duration": 1, "role": "总主持(TOM)"},
    ],
    "break": [
        {"activity_zh": "中场休息", "activity_en": "Break Time", "duration": 5, "role": "All"},
    ],
    "evaluation": [
        {"activity_zh": "TOM过渡到点评环节", "activity_en": "TOM's Transition for Evaluation", "duration": 1, "role": "总主持(TOM)"},
    ],
    "closing": [
        {"activity_zh": "TOM过渡到角色报告", "activity_en": "TOM's transition for facilitators report", "duration": 1, "role": "总主持(TOM)"},
        {"activity_zh": "时间官报告", "activity_en": "Timer report", "duration": 2, "role": "时间官(Timer)"},
        {"activity_zh": "最佳投票", "activity_en": "Vote for the Best", "duration": 1, "role": "总主持(TOM)"},
        {"activity_zh": "总点评报告", "activity_en": "General evaluator report", "duration": 7, "role": "总点评(GE)"},
        {"activity_zh": "嘉宾分享", "activity_en": "Guest sharing", "duration": 3, "role": "嘉宾分享(Guest Sharing)"},
        {"activity_zh": "颁奖环节", "activity_en": "Awarding time", "duration": 3, "role": "President"},
        {"activity_zh": "闭幕词", "activity_en": "Closing remarks", "duration": 2, "role": "President"},
        {"activity_zh": "角色预订", "activity_en": "Role booking", "duration": 1, "role": "会议经理(MM)"},
        {"activity_zh": "会议结束", "activity_en": "Meeting Adjourned", "duration": 0, "role": "-"},
    ]
}

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(meetings)")
        columns = [col[1] for col in cursor.fetchall()]
        
        # 添加英文字段
        new_fields = [
            ('english_theme', 'TEXT'),
            ('time_en', 'TEXT'),
            ('address_en', 'TEXT'),
            ('fee_info_en', 'TEXT'),
        ]
        for field, dtype in new_fields:
            if field not in columns:
                cursor.execute(f"ALTER TABLE meetings ADD COLUMN {field} {dtype}")
        
        cursor.execute("""CREATE TABLE IF NOT EXISTS meetings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            meeting_id TEXT UNIQUE NOT NULL,
            theme TEXT NOT NULL,
            english_theme TEXT,
            time TEXT NOT NULL,
            time_en TEXT,
            address TEXT,
            address_en TEXT,
            fee_info TEXT,
            fee_info_en TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        cursor.execute("""CREATE TABLE IF NOT EXISTS roles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            description TEXT
        )""")
        cursor.execute("""CREATE TABLE IF NOT EXISTS meeting_roles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            meeting_id INTEGER NOT NULL,
            role_name TEXT NOT NULL,
            FOREIGN KEY (meeting_id) REFERENCES meetings(id),
            UNIQUE(meeting_id, role_name)
        )""")
        cursor.execute("""CREATE TABLE IF NOT EXISTS members (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            is_member BOOLEAN DEFAULT 0
        )""")
        cursor.execute("""CREATE TABLE IF NOT EXISTS registrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            meeting_id INTEGER NOT NULL,
            role_name TEXT NOT NULL,
            member_name TEXT NOT NULL,
            registration_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (meeting_id) REFERENCES meetings(id),
            UNIQUE(meeting_id, role_name)
        )""")
        for role in DEFAULT_ROLES:
            try:
                cursor.execute("INSERT INTO roles (name) VALUES (?)", (role['name_zh'],))
            except sqlite3.IntegrityError:
                pass
        conn.commit()

init_db()

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def get_role_member(reg_dict, role_name):
    return reg_dict.get(role_name, '')

@app.route('/')
def index():
    conn = get_db_connection()
    meetings = conn.execute('SELECT * FROM meetings ORDER BY created_at DESC').fetchall()
    conn.close()
    return render_template('index.html', meetings=meetings)

@app.route('/meeting/create', methods=['GET', 'POST'])
def create_meeting():
    if request.method == 'POST':
        meeting_id = request.form['meeting_id']
        theme = request.form['theme']
        english_theme = request.form.get('english_theme', '')
        time = request.form['time']
        time_en = request.form.get('time_en', '')
        address = request.form.get('address', '')
        address_en = request.form.get('address_en', '')
        fee_info = request.form.get('fee_info', '')
        fee_info_en = request.form.get('fee_info_en', '')
        
        conn = get_db_connection()
        try:
            conn.execute(
                "INSERT INTO meetings (meeting_id, theme, english_theme, time, time_en, address, address_en, fee_info, fee_info_en) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (meeting_id, theme, english_theme, time, time_en, address, address_en, fee_info, fee_info_en)
            )
            meeting_db_id = conn.execute('SELECT id FROM meetings WHERE meeting_id = ?', (meeting_id,)).fetchone()['id']
            for role in DEFAULT_ROLES:
                conn.execute(
                    "INSERT INTO meeting_roles (meeting_id, role_name) VALUES (?, ?)",
                    (meeting_db_id, role['name_zh'])
                )
            conn.commit()
            flash('会议创建成功！', 'success')
            return redirect(url_for('meeting_detail', meeting_db_id=meeting_db_id))
        except sqlite3.IntegrityError:
            flash('会议编号已存在！', 'danger')
        finally:
            conn.close()
    return render_template('create_meeting.html')

@app.route('/meeting/<int:meeting_db_id>/edit', methods=['GET', 'POST'])
def edit_meeting(meeting_db_id):
    """编辑会议信息"""
    conn = get_db_connection()
    meeting = conn.execute('SELECT * FROM meetings WHERE id = ?', (meeting_db_id,)).fetchone()
    if not meeting:
        flash('会议不存在！', 'danger')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        theme = request.form['theme']
        english_theme = request.form.get('english_theme', '')
        time = request.form['time']
        time_en = request.form.get('time_en', '')
        address = request.form.get('address', '')
        address_en = request.form.get('address_en', '')
        fee_info = request.form.get('fee_info', '')
        fee_info_en = request.form.get('fee_info_en', '')
        
        conn.execute("""
            UPDATE meetings SET theme = ?, english_theme = ?, time = ?, time_en = ?, address = ?, address_en = ?, fee_info = ?, fee_info_en = ?
            WHERE id = ?
        """, (theme, english_theme, time, time_en, address, address_en, fee_info, fee_info_en, meeting_db_id))
        conn.commit()
        flash('会议信息已更新！', 'success')
        conn.close()
        return redirect(url_for('meeting_detail', meeting_db_id=meeting_db_id))
    
    conn.close()
    return render_template('edit_meeting.html', meeting=meeting)

@app.route('/meeting/<int:meeting_db_id>/export')
def export_meeting_csv(meeting_db_id):
    """导出会议报名数据为CSV"""
    conn = get_db_connection()
    meeting = conn.execute('SELECT * FROM meetings WHERE id = ?', (meeting_db_id,)).fetchone()
    if not meeting:
        flash('会议不存在！', 'danger')
        return redirect(url_for('index'))
    
    # 获取所有报名记录
    registrations = conn.execute("""
        SELECT reg.role_name, reg.member_name, reg.registration_time, m.is_member
        FROM registrations reg
        LEFT JOIN members m ON reg.member_name = m.name
        WHERE reg.meeting_id = ?
        ORDER BY reg.role_name
    """, (meeting_db_id,)).fetchall()
    conn.close()
    
    # 生成CSV
    import csv
    from flask import make_response
    
    meeting_id = meeting['meeting_id']
    meeting_theme = meeting['theme']
    meeting_time = meeting['time']
    meeting_address = meeting['address']
    
    response = make_response()
    response.headers['Content-Type'] = 'text/csv; charset=utf-8-sig'
    response.headers['Content-Disposition'] = f'attachment; filename={meeting_id}_participants.csv'
    
    import io
    output = io.StringIO()
    writer = csv.writer(output)
    
    # 标题行
    writer.writerow(['会议编号', '会议主题', '时间', '地址', '角色', '参会人员', '类型', '报名时间'])
    
    # 数据行
    for reg in registrations:
        member_type = '会员' if reg['is_member'] else '嘉宾'
        writer.writerow([
            meeting_id,
            meeting_theme,
            meeting_time,
            meeting_address or '',
            reg['role_name'],
            reg['member_name'],
            member_type,
            reg['registration_time']
        ])
    
    response.data = output.getvalue()
    return response

@app.route('/export/all')
def export_all_meetings():
    """导出所有会议报名汇总统计CSV"""
    conn = get_db_connection()
    
    # 获取所有会议
    meetings = conn.execute('SELECT * FROM meetings ORDER BY created_at DESC').fetchall()
    
    # 获取所有报名记录
    all_regs = conn.execute("""
        SELECT reg.meeting_id, m.name, m.is_member, GROUP_CONCAT(reg.role_name) as roles
        FROM registrations reg
        LEFT JOIN members m ON reg.member_name = m.name
        GROUP BY reg.meeting_id, reg.member_name
    """).fetchall()
    conn.close()
    
    # 统计每个角色的参会次数
    role_count = {}
    for reg in all_regs:
        if reg['roles']:
            for role in reg['roles'].split(','):
                role = role.strip()
                if role not in role_count:
                    role_count[role] = set()
                if reg['name']:
                    role_count[role].add(reg['name'])
    
    # 生成CSV
    import csv
    from flask import make_response
    
    response = make_response()
    response.headers['Content-Type'] = 'text/csv; charset=utf-8-sig'
    response.headers['Content-Disposition'] = 'attachment; filename=role_statistics.csv'
    
    import io
    output = io.StringIO()
    writer = csv.writer(output)
    
    # 标题行
    writer.writerow(['角色', '参会次数', '参会人员列表'])
    
    # 数据行
    for role in sorted(role_count.keys()):
        members = list(role_count[role])
        writer.writerow([role, len(members), ', '.join(sorted(members))])
    
    response.data = output.getvalue()
    return response

@app.route('/meeting/<int:meeting_db_id>')
def meeting_detail(meeting_db_id):
    conn = get_db_connection()
    meeting = conn.execute('SELECT * FROM meetings WHERE id = ?', (meeting_db_id,)).fetchone()
    if not meeting:
        flash('会议不存在！', 'danger')
        return redirect(url_for('index'))
    
    lang = session.get('lang', 'zh')
    
    roles = conn.execute("""SELECT mr.role_name, r.description, reg.member_name, m.is_member
        FROM meeting_roles mr
        LEFT JOIN registrations reg ON mr.meeting_id = reg.meeting_id AND mr.role_name = reg.role_name
        LEFT JOIN members m ON reg.member_name = m.name
        LEFT JOIN roles r ON mr.role_name = r.name
        WHERE mr.meeting_id = ?
    """, (meeting_db_id,)).fetchall()
    
    # 获取格式化的角色名、描述和是否会员专属
    roles_with_info = []
    for role in roles:
        role_name = role['role_name']
        display_name = get_role_display_name_lang(role_name, lang)
        role_desc = get_role_description(role_name, lang)
        member_only = is_member_only_role(role_name)
        roles_with_info.append({
            'role_name': role_name,
            'display_name': display_name,
            'description': role_desc,
            'member_name': role['member_name'],
            'is_member': role['is_member'],
            'member_only': member_only
        })
    
    registered_members = conn.execute("""SELECT reg.member_name, m.is_member, GROUP_CONCAT(reg.role_name) as roles
        FROM registrations reg
        LEFT JOIN members m ON reg.member_name = m.name
        WHERE reg.meeting_id = ?
        GROUP BY reg.member_name
    """, (meeting_db_id,)).fetchall()
    
    # 格式化注册人员的角色显示
    formatted_members = []
    for member in registered_members:
        roles_list = member['roles'].split(',') if member['roles'] else []
        formatted_roles = ', '.join([get_role_display_name_lang(r, lang) for r in roles_list])
        formatted_members.append({
            'member_name': member['member_name'],
            'is_member': member['is_member'],
            'roles': formatted_roles
        })
    
    conn.close()
    return render_template('meeting_detail.html', meeting=meeting, roles=roles_with_info, registered_members=formatted_members)

@app.route('/meeting/<int:meeting_db_id>/agenda')
def generate_agenda(meeting_db_id):
    lang = request.args.get('lang', 'both')
    
    conn = get_db_connection()
    meeting = conn.execute('SELECT * FROM meetings WHERE id = ?', (meeting_db_id,)).fetchone()
    if not meeting:
        flash('会议不存在！', 'danger')
        return redirect(url_for('index'))
    
    regs = conn.execute('SELECT role_name, member_name FROM registrations WHERE meeting_id = ?', (meeting_db_id,)).fetchall()
    reg_dict = {r['role_name']: r['member_name'] for r in regs}
    
    # 从会议信息中提取开始时间 - 优先使用当前语言的版本
    if lang == 'en' and meeting['time_en']:
        current_min = parse_meeting_start_time(meeting['time_en'])
    elif lang == 'both' and meeting['time_en']:
        # 中英模式：尝试解析英文时间，如果失败则用中文时间
        current_min = parse_meeting_start_time(meeting['time_en'])
        if current_min == 19 * 60 + 30:  # 如果解析失败（返回默认值）
            current_min = parse_meeting_start_time(meeting['time'])
    else:
        current_min = parse_meeting_start_time(meeting['time'])
    
    agenda = []
    
    for phase in PHASE_CONFIG:
        phase_key = phase['key']
        templates = PHASE_TEMPLATES.get(phase_key, [])
        
        for tpl in templates:
            member = get_role_member(reg_dict, tpl['role'])
            if lang == 'en':
                activity = tpl['activity_en']
            elif lang == 'zh':
                activity = tpl['activity_zh']
            else:
                activity = f"{tpl['activity_en']} {tpl['activity_zh']}"
            
            if member:
                activity += f" ({member})"
            elif tpl['role'] != '-' and tpl['role'] != 'All':
                activity += " (TBD)"
            
            agenda.append({
                "time": f"{current_min//60:02d}:{current_min%60:02d}",
                "phase": phase_key,
                "activity": activity,
                "duration": tpl['duration'],
                "role": member or ('' if tpl['role'] in ['-', 'All'] else 'TBD')
            })
            current_min += tpl['duration']
        
        # Speech: dynamic PS entries
        if phase_key == 'speech':
            for i in range(1, 5):
                ps_role = f'PS{i} 备稿演讲{i}'
                ie_role = f'IE{i} 个评{i}'
                if ps_role in reg_dict:
                    member = reg_dict[ps_role]
                    # TOM brief introduction
                    tom_member = get_role_member(reg_dict, '总主持(TOM)')
                    if lang == 'en':
                        intro = f"Brief introduction ({tom_member or 'TOM'})"
                    elif lang == 'zh':
                        intro = f"演讲介绍（{tom_member or 'TOM'}）"
                    else:
                        intro = f"Brief introduction 演讲介绍（{tom_member or 'TOM'}）"
                    
                    agenda.append({
                        "time": f"{current_min//60:02d}:{current_min%60:02d}",
                        "phase": phase_key,
                        "activity": intro,
                        "duration": 1,
                        "role": tom_member or 'TBD'
                    })
                    current_min += 1
                    
                    # PS speech
                    if lang == 'en':
                        act = f"PS{i} Prepared Speech {i} ({member})"
                    elif lang == 'zh':
                        act = f"PS{i} 备稿演讲{i}（{member}）"
                    else:
                        act = f"PS{i} Prepared Speech 备稿演讲{i}（{member}）"
                    
                    duration = 7 if i < 4 else 15  # last speech longer
                    agenda.append({
                        "time": f"{current_min//60:02d}:{current_min%60:02d}",
                        "phase": phase_key,
                        "activity": act,
                        "duration": duration,
                        "role": member
                    })
                    current_min += duration
        
        # Evaluation: dynamic IE entries
        if phase_key == 'evaluation':
            for i in range(1, 5):
                ie_role = f'IE{i} 个评{i}'
                ps_role = f'PS{i} 备稿演讲{i}'
                if ie_role in reg_dict:
                    ie_member = reg_dict[ie_role]
                    ps_member = reg_dict.get(ps_role, f'Speech {i}')
                    
                    if lang == 'en':
                        act = f"IE{i} Evaluation for {ps_member} ({ie_member})"
                    elif lang == 'zh':
                        act = f"IE{i} 点评{ps_member}（{ie_member}）"
                    else:
                        act = f"IE{i} Evaluation 点评{ps_member}（{ie_member}）"
                    
                    agenda.append({
                        "time": f"{current_min//60:02d}:{current_min%60:02d}",
                        "phase": phase_key,
                        "activity": act,
                        "duration": 3,
                        "role": ie_member
                    })
                    current_min += 3
    
    conn.close()
    return render_template('agenda.html', meeting=meeting, agenda=agenda, PHASE_CONFIG=PHASE_CONFIG, lang=lang)

@app.route('/register', methods=['POST'])
def register():
    meeting_db_id = request.form['meeting_db_id']
    role_name = request.form['role_name']
    member_name = request.form['member_name']
    is_member = request.form.get('is_member', '0') == '1'
    
    # 检查是否会员专属角色
    if is_member_only_role(role_name) and not is_member:
        flash(f'角色 {role_name} 仅限会员报名，请勾选"会员"后重新提交！', 'danger')
        return redirect(url_for('meeting_detail', meeting_db_id=meeting_db_id))
    
    conn = get_db_connection()
    try:
        existing_member = conn.execute('SELECT * FROM members WHERE name = ?', (member_name,)).fetchone()
        if not existing_member:
            conn.execute("INSERT INTO members (name, is_member) VALUES (?, ?)", (member_name, is_member))
        
        existing_reg = conn.execute('SELECT * FROM registrations WHERE meeting_id = ? AND role_name = ?', 
                                  (meeting_db_id, role_name)).fetchone()
        
        if existing_reg:
            flash(f'角色 {role_name} 已被 {existing_reg["member_name"]} 报名！', 'danger')
            return redirect(url_for('meeting_detail', meeting_db_id=meeting_db_id))
        
        user_regs = conn.execute('SELECT * FROM registrations WHERE meeting_id = ? AND member_name = ?', 
                                (meeting_db_id, member_name)).fetchall()
        
        if user_regs:
            flash(f'您已在本次会议报名了 {user_regs[0]["role_name"]}，请勿重复报名！', 'warning')
            return redirect(url_for('meeting_detail', meeting_db_id=meeting_db_id))
        
        conn.execute("INSERT INTO registrations (meeting_id, role_name, member_name) VALUES (?, ?, ?)",
                    (meeting_db_id, role_name, member_name))
        conn.commit()
        flash(f'成功报名角色 {role_name}！', 'success')
    except Exception as e:
        flash(f'报名失败：{str(e)}', 'danger')
    finally:
        conn.close()
    return redirect(url_for('meeting_detail', meeting_db_id=meeting_db_id))

@app.route('/api/meeting/<int:meeting_db_id>/roles')
def get_meeting_roles(meeting_db_id):
    conn = get_db_connection()
    roles = conn.execute("""SELECT mr.role_name, reg.member_name, m.is_member
        FROM meeting_roles mr
        LEFT JOIN registrations reg ON mr.meeting_id = reg.meeting_id AND mr.role_name = reg.role_name
        LEFT JOIN members m ON reg.member_name = m.name
        WHERE mr.meeting_id = ?
    """, (meeting_db_id,)).fetchall()
    conn.close()
    return jsonify([dict(role) for role in roles])

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8082, debug=True)