# Meeting Manager - Linux 部署指南

## 🎯 快速开始

**3 种部署方式，任选其一：**

1. ⭐ **[传统部署](DEPLOY_TRADITIONAL.md)** - 推荐新手，无需 Docker
2. 🐳 **[Docker 部署](README_DEPLOY.md)** - 适合团队，环境隔离
3. ⚙️ **Systemd 服务** - 生产环境，自动重启（传统部署已包含）

> 💡 **不知道选哪个？** → 查看 [部署决策树](DEPLOYMENT_DECISION_TREE.md)

---

## 📦 一键打包（Windows 用户）

双击运行 `package_for_deploy.bat`，会自动：
- ✅ 清理临时文件
- ✅ 复制所有必要文件
- ✅ 生成部署文档
- ✅ 创建打包目录

然后将生成的 `meeting-manager-deploy` 文件夹上传到 Linux 服务器即可。

---

## 🚀 传统部署（推荐）

```bash
# 1. 上传代码到服务器
scp -r meeting_manager user@server:/opt/

# 2. SSH 登录
ssh user@server

# 3. 运行部署
cd /opt/meeting_manager
chmod +x deploy_traditional.sh
sudo ./deploy_traditional.sh
```

访问：`http://YOUR_SERVER_IP:8000`

详细教程：[DEPLOY_TRADITIONAL.md](DEPLOY_TRADITIONAL.md)

---

## 🐳 Docker 部署

```bash
# 1. 安装 Docker（如未安装）
curl -fsSL https://get.docker.com | sh

# 2. 部署
cd /opt/meeting_manager
chmod +x deploy.sh
sudo ./deploy.sh
```

或使用 Docker Compose：
```bash
docker-compose up -d
```

详细教程：[README_DEPLOY.md](README_DEPLOY.md)

---

## 📚 完整文档

| 文档 | 说明 |
|------|------|
| [DEPLOY_QUICK.md](DEPLOY_QUICK.md) | 快速开始指南 |
| [DEPLOY_TRADITIONAL.md](DEPLOY_TRADITIONAL.md) | 传统部署详解 |
| [README_DEPLOY.md](README_DEPLOY.md) | Docker 和高级配置 |
| [DEPLOYMENT_OPTIONS.md](DEPLOYMENT_OPTIONS.md) | 部署方式对比 |
| [DEPLOYMENT_DECISION_TREE.md](DEPLOYMENT_DECISION_TREE.md) | 如何选择部署方式 |
| [DEPLOYMENT_SUMMARY.md](DEPLOYMENT_SUMMARY.md) | 部署方案总结 |

---

## 🔧 常用命令

```bash
# 查看服务状态
sudo systemctl status meeting-manager

# 查看日志
sudo journalctl -u meeting-manager -f

# 重启服务
sudo systemctl restart meeting-manager

# 备份数据库
cp /opt/meeting-manager/data/meeting.db /backup/backup_$(date +%Y%m%d).db
```

---

## ❓ 常见问题

### Q: 我应该选择哪种部署方式？
A: 查看 [部署决策树](DEPLOYMENT_DECISION_TREE.md)

### Q: 端口被占用怎么办？
A: 修改 `.env` 文件中的 `APP_PORT`，然后重启服务

### Q: 如何更新应用？
A: 上传新代码后运行 `sudo systemctl restart meeting-manager`

### Q: 数据库在哪里？
A: `/opt/meeting-manager/data/meeting.db`

更多问题：[常见问题解答](README_DEPLOY.md#常见问题)

---

## 🎉 祝您部署顺利！
